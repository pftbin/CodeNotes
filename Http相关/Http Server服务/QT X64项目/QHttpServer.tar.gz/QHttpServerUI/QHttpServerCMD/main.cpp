#include <QCoreApplication>

#include <event.h>
#include <event2/event.h>
#include <event2/http.h>
#include <event2/buffer.h>
#include <event2/util.h>
#include <event2/keyvalq_struct.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

#include "HttpServerThreadPool.h"

#define  ENABLE_OPENSSL         1
#define  ENABLE_THREADPOOL      1


// 处理 HTTP 请求的回调函数
void http_request_cb(struct evhttp_request *req, void *arg)
{
    // 由于是在线程池中回调此函数，如需使用args，注意线程安全。（args是HttpServerThreadPool对象指针）
    qDebug() << "Handling request in thread:" << QThread::currentThreadId();
    qDebug() << "Current thread count in pool:" << QThreadPool::globalInstance()->activeThreadCount();

    // 获取请求的命令（GET、POST等）
    enum evhttp_cmd_type cmd = evhttp_request_get_command(req);
    const char *cmd_str;
    switch (cmd)
    {
    case EVHTTP_REQ_GET: cmd_str = "GET"; break;
    case EVHTTP_REQ_POST: cmd_str = "POST"; break;
    case EVHTTP_REQ_PUT: cmd_str = "PUT"; break;
    case EVHTTP_REQ_DELETE: cmd_str = "DELETE"; break;
    case EVHTTP_REQ_HEAD: cmd_str = "HEAD"; break;
    case EVHTTP_REQ_OPTIONS: cmd_str = "OPTIONS"; break;
    case EVHTTP_REQ_TRACE: cmd_str = "TRACE"; break;
    case EVHTTP_REQ_CONNECT: cmd_str = "CONNECT"; break;
    default: cmd_str = "UNKNOWN"; break;
    }

    // 获取请求的URI参数
    const char *uri = evhttp_request_get_uri(req);
    qDebug() << "URI:" << uri;

    struct evkeyvalq params;
    evhttp_parse_query_str(uri, &params);
    for (struct evkeyval *param = params.tqh_first; param; param = param->next.tqe_next) {
        qDebug() << "Query Param:" << param->key << "=" << param->value;
    }
    evhttp_clear_headers(&params);

    // 获取Header参数
    struct evkeyvalq *headers = evhttp_request_get_input_headers(req);
    for (struct evkeyval *header = headers->tqh_first; header; header = header->next.tqe_next) {
        qDebug() << "Header:" << header->key << "=" << header->value;
    }

    // 获取Body参数
    struct evbuffer *input_buffer = evhttp_request_get_input_buffer(req);
    size_t length = evbuffer_get_length(input_buffer);
    char *body = (char *)malloc(length + 1);
    evbuffer_copyout(input_buffer, body, length);
    body[length] = '\0';

    qDebug() << "Body:" << body;
    free(body);

    QThread::msleep(1000);//模拟耗时操作

    struct evbuffer *buf = evbuffer_new();
    evbuffer_add_printf(buf, "Hello[from CMD], your request is %s", cmd_str);
    evhttp_send_reply(req, HTTP_OK, "OK", buf);
    evbuffer_free(buf);
}

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);


#if (!ENABLE_THREADPOOL)

#if ENABLE_OPENSSL
    SSL_library_init();
    OpenSSL_add_all_algorithms();
    ERR_load_crypto_strings();
#endif

    struct event_base *base = event_base_new();

    struct evhttp *http = evhttp_new(base);

#if ENABLE_OPENSSL
    // 设置 SSL 上下文
    SSL_CTX *ssl_ctx = SSL_CTX_new(TLS_server_method());
    if (!ssl_ctx) {
        qDebug() << "Failed to create SSL context";
        return 1;
    }

    // 加载证书和私钥
    if (SSL_CTX_use_certificate_file(ssl_ctx, "/home/baiyin/pem/certificate.pem", SSL_FILETYPE_PEM) <= 0) {
        qDebug() << "Failed to load certificate";

        // 获取错误代码
        int err = ERR_get_error();
        // 打印错误代码和描述
        char err_msg[256];
        ERR_error_string_n(err, err_msg, sizeof(err_msg));
        qDebug() << "SSL error: " << err_msg;
        return 1;
    }

    if (SSL_CTX_use_PrivateKey_file(ssl_ctx, "/home/baiyin/pem/private.key", SSL_FILETYPE_PEM) <= 0) {
        qDebug() << "Failed to load private key";

        // 获取错误代码
        int err = ERR_get_error();
        // 打印错误代码和描述
        char err_msg[256];
        ERR_error_string_n(err, err_msg, sizeof(err_msg));
        qDebug() << "SSL error: " << err_msg;
        return 1;
    }
#endif
    // 绑定端口并设置回调函数
    if (evhttp_bind_socket(http, "172.16.167.7", 8443) < 0) {
        qDebug() << "Failed to bind socket";
        return 1;
    }
    evhttp_set_gencb(http, http_request_cb, NULL);

    event_base_dispatch(base);

    evhttp_free(http);
    event_base_free(base);

#if ENABLE_OPENSSL
    SSL_CTX_free(ssl_ctx);
#endif

#else

    HttpServerThreadPool httpServerPool;
    httpServerPool.setparam(http_request_cb);
    httpServerPool.start();

    QTextStream inputStream(stdin);  // 创建一个输入流，用于从控制台读取输入
    QTextStream outputStream(stdout);  // 创建一个输出流，用于向控制台输出信息

    while (true) {
        outputStream << "请输入内容（输入Q退出程序）: ";
        outputStream.flush();

        QString input = inputStream.readLine();
        if (input.trimmed().toUpper() == "Q")
        {
            httpServerPool.stop();
            outputStream << "退出程序。";
            break;
        }
        else
        {
            outputStream << "你输入的内容是: " << input;
        }
    }

#endif

    return a.exec();
}
