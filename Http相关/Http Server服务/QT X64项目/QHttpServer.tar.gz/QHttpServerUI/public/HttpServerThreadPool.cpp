#include "HttpServerThreadPool.h"

#include <QDebug>
#include <QThread>
#include <QThreadPool>
#include <arpa/inet.h>  // 包含 inet_addr
#include <unistd.h>     // 包含 close

#include <event2/thread.h>
#include <event2/event.h>
#include <event2/http.h>
#include <event2/buffer.h>
#include <event2/util.h>
#include <event2/keyvalq_struct.h>
#include <event2/bufferevent_ssl.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

static struct bufferevent* bevcb(struct event_base* base, void* arg)
{
    struct bufferevent* r;
    SSL_CTX* ctx = (SSL_CTX*)arg;

    r = bufferevent_openssl_socket_new(base,
                                       -1,
                                       SSL_new(ctx),
                                       BUFFEREVENT_SSL_ACCEPTING,
                                       BEV_OPT_CLOSE_ON_FREE);
    return r;
}
static void server_setup_certs(SSL_CTX* ctx, const char* certificate_file, const char* private_key)
{
    qDebug() << "Loading certificate chain = "<< certificate_file <<", private key = "<< private_key;
    if (1 != SSL_CTX_use_certificate_file(ctx, certificate_file, SSL_FILETYPE_PEM))
        qDebug() << "SSL_CTX_use_certificate_chain_file";

    if (1 != SSL_CTX_use_PrivateKey_file(ctx, private_key, SSL_FILETYPE_PEM))
        qDebug() << "SSL_CTX_use_PrivateKey_file";

    if (1 != SSL_CTX_check_private_key(ctx))
        qDebug() << "SSL_CTX_check_private_key";
}

HttpServerThreadPool::HttpServerThreadPool(QObject *parent)
    : QObject(parent)
    , m_bRunning(false)
    , base(nullptr)
    , http(nullptr)
    , handle(nullptr)
    , m_threadServer(nullptr)
{
    m_bOpenSSL = false;
    m_strCertPath = "";
    m_strKeyPath = "";

    m_pFunc = nullptr;
    m_strIPAddr = "0.0.0.0";
    m_nPort = 8443;

    // 初始化 libevent 的多线程支持
    evthread_use_pthreads();
}
HttpServerThreadPool::~HttpServerThreadPool()
{
    stop();
}

void HttpServerThreadPool::setopenssl(bool _enable, std::string _certificate, std::string _privatekey)
{
    m_bOpenSSL = _enable;
    m_strCertPath = _certificate;
    m_strKeyPath = _privatekey;
}
void HttpServerThreadPool::setparam(http_cb_Func _pFunc, int _port, std::string _ipaddr)
{
    m_pFunc = _pFunc;
    m_strIPAddr = _ipaddr;
    m_nPort = _port;
}
void HttpServerThreadPool::start(int threadCount)
{
    if (m_bRunning) {
        qDebug() << "HTTP server is already running.";
        return;
    }
    m_bRunning = true;

    if (m_bOpenSSL && !m_strCertPath.empty() && !m_strKeyPath.empty())
    {
        // 初始化OpenSSL库
        SSL_library_init();
        SSL_load_error_strings();
        OpenSSL_add_all_algorithms();
    }

    m_threadServer = QThread::create([this]() {
        runHttpServer(m_pFunc, m_nPort, m_strIPAddr);
    });
    m_threadServer->start();

    // 设置线程池的大小
    threadCount = fmin(DF_MAX_THREAD, threadCount);
    QThreadPool::globalInstance()->setMaxThreadCount(threadCount);
}
void HttpServerThreadPool::stop()
{
    if (!m_bRunning) {
        qDebug() << "HTTP server is not running.";
        return;
    }
    m_bRunning = false;

    // 退出 HTTP 事件循环
    if (base) {
        event_base_loopexit(base, nullptr);
    }

    // 退出线程
    if (m_threadServer) {
        m_threadServer->wait();
        delete m_threadServer;
        m_threadServer = nullptr;
    }

    // 关闭 HTTP 服务器
    if (handle)
    {
        evhttp_del_accept_socket(http, handle);
        handle = nullptr;
    }

    // 释放 HTTP 服务器
    if (http) {
        evhttp_free(http);
        http = nullptr;
    }

    // 释放事件循环
    if (base) {
        event_base_free(base);
        base = nullptr;
    }
}

void HttpServerThreadPool::runHttpServer(http_cb_Func _pFunc, int _port, std::string _ipaddr)
{
    // 初始化libevent
    base = event_base_new();
    if (!base) {
        qDebug() << "Failed to create event base";
        return;
    }

    // 创建HTTP服务
    http = evhttp_new(base);
    if (!http) {
        qDebug() << "Failed to create HTTP server";
        return;
    }

    if (m_bOpenSSL && !m_strCertPath.empty() && !m_strKeyPath.empty())
    {
        //------OPENSSL------
        /* 创建SSL上下文环境 ，可以理解为 SSL句柄 */
        SSL_CTX* ctx = SSL_CTX_new(SSLv23_server_method());
        SSL_CTX_set_options(ctx, SSL_OP_SINGLE_DH_USE | SSL_OP_SINGLE_ECDH_USE | SSL_OP_NO_SSLv2);
        SSL_CTX_set_verify(ctx, SSL_VERIFY_NONE, NULL);

        /*选择椭圆曲线与椭圆曲线密码套件一起使用*/
        EC_KEY* ecdh = EC_KEY_new_by_curve_name(NID_X9_62_prime256v1);
        if (!ecdh)
            qDebug() << "EC_KEY_new_by_curve_name";
        if (1 != SSL_CTX_set_tmp_ecdh(ctx, ecdh))
            qDebug() << "SSL_CTX_set_tmp_ecdh";

        /* 设置服务器证书 和 服务器私钥 到 OPENSSL ctx上下文句柄中 */
        server_setup_certs(ctx, m_strCertPath.c_str(), m_strKeyPath.c_str());

        /* 使我们创建好的evhttp句柄 支持SSL加密。实际上，加密的动作和解密的动作都已经帮我们自动完成，我们拿到的数据就已经解密之后的 */
        evhttp_set_bevcb(http, bevcb, ctx);
        //------OPENSSL------
    }

    // 绑定HTTP服务到本地端口
    if (_port <= 1000) _port = 8443;
    if (_ipaddr.empty()) _ipaddr = "0.0.0.0";
    handle = evhttp_bind_socket_with_handle(http, _ipaddr.c_str(), _port);
    if (!handle) {
        qDebug() << "Failed to bind to port";
        return;
    }

    evhttp_set_timeout(http, 10); //为一个http请求设置超时时间 以秒为单位，最大10秒
    // 设置通用的请求处理函数
    if (_pFunc == nullptr)
    {
        evhttp_set_gencb(http, [](struct evhttp_request *req, void *arg) {
                HttpServerThreadPool *server = static_cast<HttpServerThreadPool*>(arg);
                QThreadPool::globalInstance()->start([server, req]() {
                    server->genericHandler(req, server);
                });
            }, this);
    }
    else
    {
        evhttp_set_gencb(http, [](struct evhttp_request *req, void *arg) {
                HttpServerThreadPool *server = static_cast<HttpServerThreadPool*>(arg);
                QThreadPool::globalInstance()->start([server, req]() {
                    server->m_pFunc(req, server);
                });
            }, this);
    }

    // 启动事件循环
    event_base_dispatch(base);
}
void HttpServerThreadPool::genericHandler(struct evhttp_request *req, void *arg)
{
    // 由于是在线程池中回调此函数，如需使用args，注意线程安全。（args是HttpServerThreadPool对象指针）
    qDebug() << "Handling request in thread:" << QThread::currentThreadId();
    qDebug() << "Current thread count in pool:" << QThreadPool::globalInstance()->activeThreadCount();

    // 获取请求的命令（GET、POST等）
    enum evhttp_cmd_type cmd = evhttp_request_get_command(req);
    const char *cmd_str;
    switch (cmd)
    {
    case EVHTTP_REQ_GET: cmd_str = "GET"; break;
    case EVHTTP_REQ_POST: cmd_str = "POST"; break;
    case EVHTTP_REQ_PUT: cmd_str = "PUT"; break;
    case EVHTTP_REQ_DELETE: cmd_str = "DELETE"; break;
    case EVHTTP_REQ_HEAD: cmd_str = "HEAD"; break;
    case EVHTTP_REQ_OPTIONS: cmd_str = "OPTIONS"; break;
    case EVHTTP_REQ_TRACE: cmd_str = "TRACE"; break;
    case EVHTTP_REQ_CONNECT: cmd_str = "CONNECT"; break;
    default: cmd_str = "UNKNOWN"; break;
    }

    // 获取请求的URI参数
    const char *uri = evhttp_request_get_uri(req);
    qDebug() << "URI:" << uri;

    struct evkeyvalq params;
    evhttp_parse_query_str(uri, &params);
    for (struct evkeyval *param = params.tqh_first; param; param = param->next.tqe_next) {
        qDebug() << "Query Param:" << param->key << "=" << param->value;
    }
    evhttp_clear_headers(&params);

    // 获取Header参数
    struct evkeyvalq *headers = evhttp_request_get_input_headers(req);
    for (struct evkeyval *header = headers->tqh_first; header; header = header->next.tqe_next) {
        qDebug() << "Header:" << header->key << "=" << header->value;
    }

    // 获取Body参数
    struct evbuffer *input_buffer = evhttp_request_get_input_buffer(req);
    size_t length = evbuffer_get_length(input_buffer);
    char *body = (char *)malloc(length + 1);
    evbuffer_copyout(input_buffer, body, length);
    body[length] = '\0';

    qDebug() << "Body:" << body;
    free(body);

    QThread::msleep(1000);//模拟耗时操作

    struct evbuffer *buf = evbuffer_new();
    evbuffer_add_printf(buf, "Hello, your request is %s", cmd_str);
    evhttp_send_reply(req, HTTP_OK, "OK", buf);
    evbuffer_free(buf);
}
