#ifndef HTTPSERVERTHREADPOOL_H
#define HTTPSERVERTHREADPOOL_H

#include <QThread>
#include <QThreadPool>
#include <QDebug>

#include <event.h>
#include <event2/thread.h>
#include <event2/event.h>
#include <event2/http.h>
#include <event2/buffer.h>
#include <event2/util.h>
#include <event2/keyvalq_struct.h>
#include <openssl/ssl.h>
#include <openssl/err.h>


#define  DF_MAX_THREAD   100
typedef void (*http_cb_Func)(struct evhttp_request *req, void *arg);

class HttpServerThreadPool : public QObject
{
    Q_OBJECT

public:
    HttpServerThreadPool(QObject *parent = nullptr);
    ~HttpServerThreadPool();

    void setopenssl(bool _enable, std::string _certificate, std::string _privatekey);
    void setparam(http_cb_Func _pFunc, int _port = 8443, std::string _ipAddr = "0.0.0.0");
    void start(int threadCount = 10);  // 启动HTTP服务，并指定线程池中线程的个数
    void stop();  // 停止HTTP服务

private:
    void runHttpServer(http_cb_Func _pFunc, int _port, std::string _ipaddr);
    static void genericHandler(struct evhttp_request *req, void *arg);

private:
    bool                        m_bRunning;
    struct event_base*          base;
    struct evhttp*              http;
    struct evhttp_bound_socket* handle;
    QThread*                    m_threadServer;

    bool                        m_bOpenSSL;
    std::string                 m_strCertPath;
    std::string                 m_strKeyPath;

    http_cb_Func                m_pFunc;
    int                         m_nPort;
    std::string                 m_strIPAddr;
    int                         m_nSocket;

};


#endif // HTTPSERVERTHREADPOOL_H
