#include "QHttpServerUI.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QHttpServerUI w;
    w.show();
    return a.exec();
}
