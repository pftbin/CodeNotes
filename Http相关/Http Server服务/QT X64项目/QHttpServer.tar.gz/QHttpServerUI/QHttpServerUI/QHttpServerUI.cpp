#include "QHttpServerUI.h"
#include "ui_QHttpServerUI.h"

QHttpServerUI::QHttpServerUI(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::QHttpServerUI)
{
    ui->setupUi(this);

    QString state= "CLOSE";
    ui->label_Satae->setText(QString("服务状态：%1").arg(state));
}

QHttpServerUI::~QHttpServerUI()
{
    on_pushButton_2_clicked();
    delete ui;
}


void QHttpServerUI::genericHandler(struct evhttp_request *req, void *arg)
{
    // 由于是在线程池中回调此函数，如需使用args，注意线程安全。（args是HttpServerThreadPool对象指针）
    qDebug() << "Handling request in thread:" << QThread::currentThreadId();
    qDebug() << "Current thread count in pool:" << QThreadPool::globalInstance()->activeThreadCount();

    // 获取请求的命令（GET、POST等）
    enum evhttp_cmd_type cmd = evhttp_request_get_command(req);
    const char *cmd_str;
    switch (cmd)
    {
    case EVHTTP_REQ_GET: cmd_str = "GET"; break;
    case EVHTTP_REQ_POST: cmd_str = "POST"; break;
    case EVHTTP_REQ_PUT: cmd_str = "PUT"; break;
    case EVHTTP_REQ_DELETE: cmd_str = "DELETE"; break;
    case EVHTTP_REQ_HEAD: cmd_str = "HEAD"; break;
    case EVHTTP_REQ_OPTIONS: cmd_str = "OPTIONS"; break;
    case EVHTTP_REQ_TRACE: cmd_str = "TRACE"; break;
    case EVHTTP_REQ_CONNECT: cmd_str = "CONNECT"; break;
    default: cmd_str = "UNKNOWN"; break;
    }

    // 获取请求的URI参数
    const char *uri = evhttp_request_get_uri(req);
    qDebug() << "URI:" << uri;

    struct evkeyvalq params;
    evhttp_parse_query_str(uri, &params);
    for (struct evkeyval *param = params.tqh_first; param; param = param->next.tqe_next) {
        qDebug() << "Query Param:" << param->key << "=" << param->value;
    }
    evhttp_clear_headers(&params);

    // 获取Header参数
    struct evkeyvalq *headers = evhttp_request_get_input_headers(req);
    for (struct evkeyval *header = headers->tqh_first; header; header = header->next.tqe_next) {
        qDebug() << "Header:" << header->key << "=" << header->value;
    }

    // 获取Body参数
    struct evbuffer *input_buffer = evhttp_request_get_input_buffer(req);
    size_t length = evbuffer_get_length(input_buffer);
    char *body = (char *)malloc(length + 1);
    evbuffer_copyout(input_buffer, body, length);
    body[length] = '\0';

    qDebug() << "Body:" << body;
    free(body);

    QThread::msleep(1000);//模拟耗时操作

    struct evbuffer *buf = evbuffer_new();
    evbuffer_add_printf(buf, "Hello[from UI], your request is %s", cmd_str);
    evhttp_send_reply(req, HTTP_OK, "OK", buf);
    evbuffer_free(buf);


}
void QHttpServerUI::on_pushButton_clicked()
{
    bool bOpenSSL = true;

    httpServerPool.setparam(genericHandler);
    httpServerPool.setopenssl(bOpenSSL, "/home/baiyin/pem/server.crt", "/home/baiyin/pem/server.key");
    httpServerPool.start();

    QString state= "OPEN";
    QString type = (bOpenSSL)?("HTTPS"):("HTTP");
    ui->label_Satae->setText(QString("服务状态：%1 \n服务类型：%2").arg(state).arg(type));
}
void QHttpServerUI::on_pushButton_2_clicked()
{
    httpServerPool.stop();

    QString state= "CLOSE";
    ui->label_Satae->setText(QString("服务状态：%1").arg(state));
}

