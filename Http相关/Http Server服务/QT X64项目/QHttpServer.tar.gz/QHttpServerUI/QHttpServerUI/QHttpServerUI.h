#ifndef QHTTPSERVERUI_H
#define QHTTPSERVERUI_H

#include <QMainWindow>

#include "HttpServerThreadPool.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class QHttpServerUI;
}
QT_END_NAMESPACE

class QHttpServerUI : public QMainWindow
{
    Q_OBJECT

public:
    QHttpServerUI(QWidget *parent = nullptr);
    ~QHttpServerUI();

protected:
    static void genericHandler(struct evhttp_request *req, void *arg);
    HttpServerThreadPool httpServerPool;

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();

private:
    Ui::QHttpServerUI *ui;
};
#endif // QHTTPSERVERUI_H
